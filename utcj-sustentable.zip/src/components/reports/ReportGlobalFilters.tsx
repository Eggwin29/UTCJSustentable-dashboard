import {
  FiCalendar,
  FiFilter,
  FiInfo,
  FiRefreshCw,
} from "react-icons/fi";

import Badge from "@/components/ui/Badge/Badge";
import Button from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Dropdown from "@/components/ui/select";

import type {
  ReportFilterOptions,
  ReportFilters,
  ReportPeriodMode,
} from "@/types/reportes";

interface ReportGlobalFiltersProps {
  filters: ReportFilters;
  options: ReportFilterOptions | null;
  isLoading: boolean;
  error: Error | null;
  activeFilterCount: number;

  onChange: (
    changes: Partial<ReportFilters>
  ) => void;

  onReset: () => void;
}

const periodOptions = [
  {
    value: "all",
    label: "Todo el historial",
  },
  {
    value: "year",
    label: "Filtrar por año",
  },
  {
    value: "academic-term",
    label: "Filtrar por cuatrimestre",
  },
];

export default function ReportGlobalFilters({
  filters,
  options,
  isLoading,
  error,
  activeFilterCount,
  onChange,
  onReset,
}: ReportGlobalFiltersProps) {
  const years =
    options?.years ?? [];

  const academicTerms =
    options?.academicTerms ?? [];

  const handlePeriodModeChange = (
    value: string | number
  ) => {
    const periodMode =
      String(
        value
      ) as ReportPeriodMode;

    if (periodMode === "all") {
      onChange({
        periodMode,
        year: null,
        academicTermId: null,
      });

      return;
    }

    if (periodMode === "year") {
      onChange({
        periodMode,

        year:
          filters.year ??
          years[0] ??
          null,

        academicTermId: null,
      });

      return;
    }

    onChange({
      periodMode,
      year: null,

      academicTermId:
        filters.academicTermId ??
        academicTerms[0]?.id ??
        null,
    });
  };

  const activeLabels =
    getActiveFilterLabels(
      filters,
      options
    );

  return (
    <Card variant="outlined">
      <Card.Header>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <div className="rounded-xl bg-emerald-100 p-2.5 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
              <FiFilter
                size={20}
                aria-hidden="true"
              />
            </div>

            <div>
              <Card.Title>
                Filtros del reporte
              </Card.Title>

              <Card.Description>
                El periodo se aplica a todas las secciones. Los filtros específicos se controlan dentro de cada bloque.
              </Card.Description>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Badge
              variant={
                activeFilterCount > 0
                  ? "primary"
                  : "secondary"
              }
              size="md"
            >
              {activeFilterCount === 0
                ? "Sin filtros activos"
                : `${activeFilterCount} ${
                    activeFilterCount === 1
                      ? "filtro activo"
                      : "filtros activos"
                  }`}
            </Badge>

            <Button
              type="button"
              variant="ghost"
              size="sm"
              leftIcon={
                <FiRefreshCw />
              }
              onClick={onReset}
              disabled={
                activeFilterCount === 0
              }
            >
              Limpiar todo
            </Button>
          </div>
        </div>
      </Card.Header>

      <Card.Body className="space-y-5">
        <div className="grid gap-4 md:grid-cols-2">
          <Dropdown
            id="report-period-mode"
            label="Periodo global"
            leftIcon={<FiCalendar />}
            options={periodOptions}
            value={filters.periodMode}
            onChange={
              handlePeriodModeChange
            }
            disabled={isLoading}
          />

          {filters.periodMode ===
            "year" && (
            <Dropdown
              id="report-year"
              label="Año"
              options={years.map(
                (year) => ({
                  value: year,
                  label: String(year),
                })
              )}
              value={
                filters.year ??
                undefined
              }
              onChange={(value) =>
                onChange({
                  year: Number(value),
                })
              }
              placeholder="Selecciona un año"
              disabled={
                isLoading ||
                years.length === 0
              }
            />
          )}

          {filters.periodMode ===
            "academic-term" && (
            <Dropdown
              id="report-academic-term"
              label="Cuatrimestre"
              options={academicTerms.map(
                (academicTerm) => ({
                  value:
                    academicTerm.id,

                  label:
                    academicTerm.label,
                })
              )}
              value={
                filters.academicTermId ??
                undefined
              }
              onChange={(value) =>
                onChange({
                  academicTermId:
                    String(value),
                })
              }
              placeholder="Selecciona un cuatrimestre"
              disabled={
                isLoading ||
                academicTerms.length ===
                  0
              }
            />
          )}

          {filters.periodMode ===
            "all" && (
            <div className="flex min-h-18 items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-950/50">
              <div>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                  Vista histórica completa
                </p>

                <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">
                  Incluye registros históricos con y sin cuatrimestre relacionado.
                </p>
              </div>
            </div>
          )}
        </div>

        {error && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300">
            No se pudieron cargar las opciones de filtrado. Recarga la página para intentarlo nuevamente.
          </div>
        )}

        {filters.periodMode ===
          "academic-term" && (
          <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-300">
            <FiInfo
              className="mt-0.5 shrink-0"
              aria-hidden="true"
            />

            <p>
              Al filtrar por cuatrimestre, los registros históricos que no tienen un periodo relacionado quedan fuera del resultado. No se modifica ni se inventa información histórica.
            </p>
          </div>
        )}

        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">
            Vista actual
          </p>

          <div className="flex flex-wrap gap-2">
            {activeLabels.length ===
            0 ? (
              <Badge
                variant="secondary"
                size="md"
              >
                Todo el historial
              </Badge>
            ) : (
              activeLabels.map(
                (label) => (
                  <Badge
                    key={label}
                    variant="outline"
                    size="md"
                  >
                    {label}
                  </Badge>
                )
              )
            )}
          </div>
        </div>
      </Card.Body>
    </Card>
  );
}

function getActiveFilterLabels(
  filters: ReportFilters,
  options: ReportFilterOptions | null
): string[] {
  const labels: string[] = [];

  if (
    filters.periodMode === "year" &&
    filters.year !== null
  ) {
    labels.push(
      `Año: ${filters.year}`
    );
  }

  if (
    filters.periodMode ===
      "academic-term" &&
    filters.academicTermId
  ) {
    const academicTerm =
      options?.academicTerms.find(
        (option) =>
          option.id ===
          filters.academicTermId
      );

    labels.push(
      `Cuatrimestre: ${
        academicTerm?.label ??
        "seleccionado"
      }`
    );
  }

  if (filters.material) {
    labels.push(
      `Material: ${filters.material}`
    );
  }

  if (
    filters.personalTurn === "tm"
  ) {
    labels.push(
      "Turno: TM Martes"
    );
  }

  if (
    filters.personalTurn === "tv"
  ) {
    labels.push(
      "Turno: TV Jueves"
    );
  }

  if (filters.academicProgramId) {
    const academicProgram =
      options?.academicPrograms.find(
        (option) =>
          option.id ===
          filters.academicProgramId
      );

    labels.push(
      `Carrera: ${
        academicProgram?.name ??
        "seleccionada"
      }`
    );
  }

  if (filters.academicLevel) {
    labels.push(
      `Nivel: ${filters.academicLevel}`
    );
  }

  return labels;
}