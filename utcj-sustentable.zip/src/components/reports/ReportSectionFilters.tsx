import {
  FiFilter,
  FiX,
} from "react-icons/fi";

import Button from "@/components/ui/button";
import Dropdown from "@/components/ui/select";

import type {
  AcademicLevel,
} from "@/types/internshipParticipation";

import type {
  PersonalTurnFilter,
  ReportFilterOptions,
  ReportFilters,
} from "@/types/reportes";

type ReportSection =
  | "waste"
  | "human-capital"
  | "internships";

interface ReportSectionFiltersProps {
  section: ReportSection;
  filters: ReportFilters;
  options: ReportFilterOptions | null;
  isLoading: boolean;

  onChange: (
    changes: Partial<ReportFilters>
  ) => void;
}

const ALL_VALUE = "__all__";

const turnOptions = [
  {
    value: "all",
    label: "Todos los turnos",
  },
  {
    value: "tm",
    label: "TM Martes",
  },
  {
    value: "tv",
    label: "TV Jueves",
  },
];

export default function ReportSectionFilters({
  section,
  filters,
  options,
  isLoading,
  onChange,
}: ReportSectionFiltersProps) {
  const activeCount =
    getSectionActiveCount(
      section,
      filters
    );

  const resetSection = () => {
    if (section === "waste") {
      onChange({
        material: null,
      });

      return;
    }

    if (
      section === "human-capital"
    ) {
      onChange({
        personalTurn: "all",
      });

      return;
    }

    onChange({
      academicProgramId: null,
      academicLevel: null,
    });
  };

  return (
    <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-950/40">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <FiFilter
            className="text-emerald-600 dark:text-emerald-400"
            aria-hidden="true"
          />

          <div>
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
              Filtros de esta sección
            </p>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              {getSectionDescription(
                section
              )}
            </p>
          </div>
        </div>

        <Button
          type="button"
          variant="ghost"
          size="sm"
          leftIcon={<FiX />}
          onClick={resetSection}
          disabled={activeCount === 0}
        >
          Limpiar sección
        </Button>
      </div>

      {section === "waste" && (
        <div className="max-w-sm">
          <Dropdown
            id="report-material-filter"
            label="Material"
            options={[
              {
                value: ALL_VALUE,
                label:
                  "Todos los materiales",
              },

              ...(
                options?.materials ?? []
              ).map((material) => ({
                value: material,
                label: material,
              })),
            ]}
            value={
              filters.material ??
              ALL_VALUE
            }
            onChange={(value) =>
              onChange({
                material:
                  value === ALL_VALUE
                    ? null
                    : String(value),
              })
            }
            disabled={isLoading}
          />
        </div>
      )}

      {section ===
        "human-capital" && (
        <div className="max-w-sm">
          <Dropdown
            id="report-turn-filter"
            label="Turno"
            options={turnOptions}
            value={
              filters.personalTurn
            }
            onChange={(value) =>
              onChange({
                personalTurn:
                  String(
                    value
                  ) as PersonalTurnFilter,
              })
            }
            disabled={isLoading}
          />
        </div>
      )}

      {section === "internships" && (
        <div className="grid gap-4 md:grid-cols-2">
          <Dropdown
            id="report-program-filter"
            label="Carrera"
            options={[
              {
                value: ALL_VALUE,
                label:
                  "Todas las carreras",
              },

              ...(
                options?.academicPrograms ??
                []
              ).map(
                (academicProgram) => ({
                  value:
                    academicProgram.id,

                  label:
                    academicProgram.name,
                })
              ),
            ]}
            value={
              filters.academicProgramId ??
              ALL_VALUE
            }
            onChange={(value) =>
              onChange({
                academicProgramId:
                  value === ALL_VALUE
                    ? null
                    : String(value),
              })
            }
            disabled={isLoading}
          />

          <Dropdown
            id="report-level-filter"
            label="Nivel académico"
            options={[
              {
                value: ALL_VALUE,
                label:
                  "Todos los niveles",
              },

              ...(
                options?.academicLevels ??
                []
              ).map((level) => ({
                value: level,
                label: level,
              })),
            ]}
            value={
              filters.academicLevel ??
              ALL_VALUE
            }
            onChange={(value) =>
              onChange({
                academicLevel:
                  value === ALL_VALUE
                    ? null
                    : (String(
                        value
                      ) as AcademicLevel),
              })
            }
            disabled={isLoading}
          />
        </div>
      )}
    </div>
  );
}

function getSectionActiveCount(
  section: ReportSection,
  filters: ReportFilters
): number {
  if (section === "waste") {
    return filters.material
      ? 1
      : 0;
  }

  if (
    section === "human-capital"
  ) {
    return filters.personalTurn ===
      "all"
      ? 0
      : 1;
  }

  return (
    Number(
      Boolean(
        filters.academicProgramId
      )
    ) +
    Number(
      Boolean(
        filters.academicLevel
      )
    )
  );
}

function getSectionDescription(
  section: ReportSection
): string {
  if (section === "waste") {
    return "Afecta los indicadores, gráficas y resumen de materiales.";
  }

  if (
    section === "human-capital"
  ) {
    return "Permite analizar ambos turnos o uno de forma individual.";
  }

  return "Combina carrera y nivel académico en los resultados de estadías.";
}