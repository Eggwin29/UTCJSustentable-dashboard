import type {
  AcademicTermCode,
} from "@/types/academicTerm";

import type {
  AcademicLevel,
} from "@/types/internshipParticipation";

export type ReportPeriodMode =
  | "all"
  | "year"
  | "academic-term";

export type PersonalTurnFilter =
  | "all"
  | "tm"
  | "tv";

export interface ReportFilters {
  periodMode: ReportPeriodMode;
  year: number | null;
  academicTermId: string | null;

  material: string | null;

  personalTurn: PersonalTurnFilter;

  academicProgramId: string | null;
  academicLevel: AcademicLevel | null;
}

export const DEFAULT_REPORT_FILTERS:
  ReportFilters = {
    periodMode: "all",
    year: null,
    academicTermId: null,
    material: null,
    personalTurn: "all",
    academicProgramId: null,
    academicLevel: null,
  };

export interface ReportAcademicTermOption {
  id: string;
  label: string;
  year: number;
  term: AcademicTermCode;
}

export interface ReportAcademicProgramOption {
  id: string;
  name: string;
}

export interface ReportFilterOptions {
  years: number[];
  academicTerms: ReportAcademicTermOption[];
  materials: string[];
  academicPrograms: ReportAcademicProgramOption[];
  academicLevels: AcademicLevel[];
}

export interface ResiduoRecord {
  año: number;
  tipoResiduo: string;
  kilogramos: number;
}

export interface PersonalRecord {
  cuatrimestre: string;
  tmMartes: number;
  tvJueves: number;
}

export interface MaterialTotal {
  tipoResiduo: string;
  totalKg: number;
  co2Evitado: number;
}

export interface AñoTotal {
  año: number;
  totalKg: number;
  co2Evitado: number;
  porcentaje: number;
}

export interface EstadiasPorCarrera {
  carrera: string;
  participantes: number;
}

export interface EstadiasPorCuatrimestre {
  cuatrimestre: string;
  participantes: number;
}

export interface EstadiasPorNivel {
  nivel: AcademicLevel;
  participantes: number;
}

export interface EstadiasTotales {
  registros: number;
  cuatrimestres: number;
  carreras: number;
  participantes: number;
}