import { supabase } from "@/lib/supabase";

import type {
  CollectionListItem,
  CreateCollectionInput,
} from "@/types/collection";

export const collectionsService = {
  // =====================================================
  // OBTENER RECOLECCIONES
  // =====================================================

  async getAll(): Promise<CollectionListItem[]> {
    const { data, error } = await supabase
      .from("waste_collections")
      .select(
        `
          id,
          collection_date,
          material_id,
          kilograms,
          location,
          notes,
          created_by,
          created_at,
          updated_at,
          materials (
            id,
            name
          )
        `
      )
      .order("collection_date", {
        ascending: false,
      });

    if (error) {
      throw error;
    }

    return data.map((collection) => ({
      id: collection.id,
      date: collection.collection_date,
      materialId: collection.material_id,
      kilograms: collection.kilograms,
      location: collection.location,
      notes: collection.notes,
      createdBy: collection.created_by,
      createdAt: collection.created_at,
      updatedAt: collection.updated_at,

      materialName:
        collection.materials?.name ?? "Sin material",
    }));
  },

  // =====================================================
  // CREAR RECOLECCIÓN
  // =====================================================

  async create(
    input: CreateCollectionInput
  ): Promise<CollectionListItem> {
    const { data, error } = await supabase
      .from("waste_collections")
      .insert({
        collection_date: input.date,
        material_id: input.materialId,
        kilograms: input.kilograms,

        location:
          input.location?.trim() || null,

        notes:
          input.notes?.trim() || null,

        created_by: input.createdBy,
      })
      .select(
        `
          id,
          collection_date,
          material_id,
          kilograms,
          location,
          notes,
          created_by,
          created_at,
          updated_at,
          materials (
            id,
            name
          )
        `
      )
      .single();

    if (error) {
      throw error;
    }

    return {
      id: data.id,
      date: data.collection_date,
      materialId: data.material_id,
      kilograms: data.kilograms,
      location: data.location,
      notes: data.notes,
      createdBy: data.created_by,
      createdAt: data.created_at,
      updatedAt: data.updated_at,

      materialName:
        data.materials?.name ?? "Sin material",
    };
  },
};