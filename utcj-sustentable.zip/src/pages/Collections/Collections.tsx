import { useEffect, useState } from "react";
import { FiInbox, FiPlus } from "react-icons/fi";

import Button from "@/components/ui/button";
import { Table } from "@/components/ui/table";

import CollectionForm from "@/components/forms/CollectionForm";

import { collectionsService } from "@/services/collectionsService";
import { materialsService } from "@/services/materialsService";

import { useAuth } from "@/context/auth/useAuth";

import type { CollectionListItem } from "@/types/collection";
import type { Material } from "@/types/material";

export default function Collections() {
  const { user } = useAuth();

  const [collections, setCollections] =
    useState<CollectionListItem[]>([]);

  const [materials, setMaterials] =
    useState<Material[]>([]);

  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] =
    useState("");

  const [showForm, setShowForm] =
    useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        setErrorMessage("");

        const [
          collectionsData,
          materialsData,
        ] = await Promise.all([
          collectionsService.getAll(),
          materialsService.getActive(),
        ]);

        setCollections(collectionsData);
        setMaterials(materialsData);
      } catch (error) {
        console.error(
          "Error cargando colecciones:",
          error
        );

        setErrorMessage(
          "No se pudieron cargar las colecciones."
        );
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const handleCreated = (
    collection: CollectionListItem
  ) => {
    setCollections((current) => [
      collection,
      ...current,
    ]);

    setShowForm(false);
  };

  if (loading) {
    return (
      <div className="p-6">
        <p className="text-sm text-slate-500">
          Cargando colecciones...
        </p>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="p-6">
        <p className="text-sm text-red-600">
          {errorMessage}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* ==================================================
          ENCABEZADO
      ================================================== */}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">
            Colecciones
          </h1>

          <p className="mt-1 text-sm text-slate-500">
            Registro y administración de residuos recolectados.
          </p>
        </div>

        {!showForm && (
          <Button
            leftIcon={<FiPlus />}
            onClick={() => setShowForm(true)}
          >
            Nueva recolección
          </Button>
        )}
      </div>

      {/* ==================================================
          FORMULARIO
      ================================================== */}

      {showForm && user && (
        <CollectionForm
          materials={materials}
          userId={user.id}
          onCreated={handleCreated}
          onCancel={() => setShowForm(false)}
        />
      )}

      {/* ==================================================
          RESUMEN
      ================================================== */}

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm font-medium text-slate-500">
            Recolecciones registradas
          </p>

          <p className="mt-1 text-3xl font-bold text-slate-800">
            {collections.length}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm font-medium text-slate-500">
            Materiales activos
          </p>

          <p className="mt-1 text-3xl font-bold text-slate-800">
            {materials.length}
          </p>
        </div>
      </div>

      {/* ==================================================
          TABLA
      ================================================== */}

      <div>
        <div className="mb-3">
          <h2 className="font-semibold text-slate-800">
            Historial de recolecciones
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Registros almacenados en UTCJ Sustentable.
          </p>
        </div>

        <Table>
          <Table.Head>
            <Table.Row>
              <Table.HeaderCell>
                Fecha
              </Table.HeaderCell>

              <Table.HeaderCell>
                Material
              </Table.HeaderCell>

              <Table.HeaderCell align="right">
                Peso
              </Table.HeaderCell>

              <Table.HeaderCell>
                Ubicación
              </Table.HeaderCell>

              <Table.HeaderCell>
                Observaciones
              </Table.HeaderCell>
            </Table.Row>
          </Table.Head>

          <Table.Body>
            {collections.length === 0 ? (
              <Table.Empty
                colSpan={5}
                icon={<FiInbox size={30} />}
                title="No hay recolecciones"
                description="Registra la primera recolección para comenzar a generar información."
              />
            ) : (
              collections.map((collection) => (
                <Table.Row key={collection.id}>
                  <Table.Cell>
                    {formatDate(collection.date)}
                  </Table.Cell>

                  <Table.Cell>
                    <span className="font-medium text-slate-800">
                      {collection.materialName}
                    </span>
                  </Table.Cell>

                  <Table.Cell align="right">
                    <span className="font-semibold">
                      {formatKilograms(
                        collection.kilograms
                      )}
                    </span>
                  </Table.Cell>

                  <Table.Cell>
                    {collection.location || "—"}
                  </Table.Cell>

                  <Table.Cell>
                    <span className="block max-w-xs truncate">
                      {collection.notes || "—"}
                    </span>
                  </Table.Cell>
                </Table.Row>
              ))
            )}
          </Table.Body>
        </Table>
      </div>
    </div>
  );
}

function formatDate(date: string) {
  const [year, month, day] = date.split("-");

  return `${day}/${month}/${year}`;
}

function formatKilograms(kilograms: number) {
  return new Intl.NumberFormat("es-MX", {
    maximumFractionDigits: 3,
  }).format(kilograms) + " kg";
}