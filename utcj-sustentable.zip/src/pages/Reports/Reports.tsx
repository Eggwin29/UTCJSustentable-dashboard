import {
  useMemo,
  useState,
} from "react";

import {
  FiInbox,
} from "react-icons/fi";

import Co2PorAñoChart from "@/components/charts/Co2PorAñoChart";
import DistribucionPorAñoChart from "@/components/charts/DistribucionPorAñoChart";
import EstadiasPorCarreraChart from "@/components/charts/EstadiasPorCarreraChart";
import EstadiasPorCuatrimestreChart from "@/components/charts/EstadiasPorCuatrimestreChart";
import EstadiasPorNivelChart from "@/components/charts/EstadiasPorNivelChart";
import ImpactoAmbientalChart from "@/components/charts/ImpactoAmbientalChart";
import LazyChartMount from "@/components/charts/LazyChartMount";
import MaterialesRecicladosChart from "@/components/charts/MaterialesRecicladosChart";
import PersonalPorTurnoChart from "@/components/charts/PersonalPorTurnoChart";
import PersonalTotalPorCuatrimestreChart from "@/components/charts/PersonalTotalPorCuatrimestreChart";
import PersonalTotalPorTurnoChart from "@/components/charts/PersonalTotalPorTurnoChart";
import ResiduosPorAñoChart from "@/components/charts/ResiduosPorAñoChart";
import ResumenMaterialesTable from "@/components/charts/ResumenMaterialesTable";
import StatCard from "@/components/charts/StatCard";

import ComponentSection from "@/components/ComponentSection/ComponentSection";

import ReportGlobalFilters from "@/components/reports/ReportGlobalFilters";
import ReportSectionFilters from "@/components/reports/ReportSectionFilters";

import {
  useAsyncData,
} from "@/hooks/useAsyncData";

import {
  getReportesData,
  getReportFilterOptions,
} from "@/services/reportsService";

import {
  DEFAULT_REPORT_FILTERS,
} from "@/types/reportes";

import type {
  ReportFilters,
} from "@/types/reportes";

export default function Reportes() {
  const [filters, setFilters] =
    useState<ReportFilters>(() => ({
      ...DEFAULT_REPORT_FILTERS,
    }));

  const {
    data: filterOptions,
    isLoading:
      loadingFilterOptions,
    error: filterOptionsError,
  } = useAsyncData(
    getReportFilterOptions
  );

  const {
    data,
    isLoading,
    error,
  } = useAsyncData(
    () => getReportesData(filters),
    [filters]
  );

  const activeFilterCount =
    useMemo(
      () =>
        countActiveFilters(
          filters
        ),
      [filters]
    );

  const updateFilters = (
    changes: Partial<ReportFilters>
  ) => {
    setFilters((current) => ({
      ...current,
      ...changes,
    }));
  };

  const resetFilters = () => {
    setFilters({
      ...DEFAULT_REPORT_FILTERS,
    });
  };

  const hasWasteResults =
    (
      data?.materialTotals.length ??
      0
    ) > 0;

  const hasHumanCapitalResults =
    (
      data?.personalPorCuatrimestre
        .length ?? 0
    ) > 0;

  const hasInternshipResults =
    (
      data?.estadiasTotales
        .registros ?? 0
    ) > 0;

  return (
    <div className="space-y-10">
      <section>
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
          Reportes
        </h1>

        <p className="mt-2 text-slate-500 dark:text-slate-400">
          Indicadores históricos de recolección, impacto ambiental y participación en UTCJ Sustentable.
        </p>
      </section>

      <ReportGlobalFilters
        filters={filters}
        options={filterOptions}
        isLoading={
          loadingFilterOptions
        }
        error={filterOptionsError}
        activeFilterCount={
          activeFilterCount
        }
        onChange={updateFilters}
        onReset={resetFilters}
      />

      <div className="grid gap-6 md:grid-cols-2">
        <StatCard
          label={
            filters.periodMode ===
              "all" &&
            filters.material === null
              ? "Total Recolección Histórica"
              : "Total Recolección Filtrada"
          }
          value={
            data?.totalHistorico ?? 0
          }
          unit="kg"
          isLoading={isLoading}
          accent="emerald"
        />

        <StatCard
          label="CO₂ Evitado"
          value={
            data?.co2Total ?? 0
          }
          unit="kg"
          isLoading={isLoading}
          accent="sky"
        />
      </div>

      <ComponentSection
        title="Residuos"
        description="Recolección de material reciclado."
      >
        <ReportSectionFilters
          section="waste"
          filters={filters}
          options={filterOptions}
          isLoading={
            loadingFilterOptions
          }
          onChange={updateFilters}
        />

        {!isLoading &&
        !error &&
        !hasWasteResults ? (
          <NoResultsNotice
            title="Sin datos de residuos"
            description="No hay recolecciones que coincidan con el periodo y material seleccionados."
          />
        ) : (
          <>
            <div className="grid gap-6 lg:grid-cols-2">
              <LazyChartMount>
                <MaterialesRecicladosChart
                  data={
                    data?.materialTotals ??
                    []
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>

              <LazyChartMount>
                <DistribucionPorAñoChart
                  data={
                    data?.añoTotals ??
                    []
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>

              <LazyChartMount>
                <ResiduosPorAñoChart
                  years={
                    data?.availableYears ??
                    []
                  }
                  dataByYear={
                    data?.residuosPorAño ??
                    {}
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>

              <LazyChartMount>
                <Co2PorAñoChart
                  data={
                    data?.añoTotals ??
                    []
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>
            </div>

            <div className="mt-6">
              <LazyChartMount>
                <ImpactoAmbientalChart
                  data={
                    data?.materialTotals ??
                    []
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>
            </div>
          </>
        )}
      </ComponentSection>

      <ComponentSection
        title="Capital humano"
        description="Asistencia por turno y cuatrimestre."
      >
        <ReportSectionFilters
          section="human-capital"
          filters={filters}
          options={filterOptions}
          isLoading={
            loadingFilterOptions
          }
          onChange={updateFilters}
        />

        {!isLoading &&
        !error &&
        !hasHumanCapitalResults ? (
          <NoResultsNotice
            title="Sin datos de Capital humano"
            description="No hay registros de participación para el periodo seleccionado."
          />
        ) : (
          <div className="grid gap-6 lg:grid-cols-2">
            <LazyChartMount>
              <PersonalPorTurnoChart
                data={
                  data?.personalPorCuatrimestre ??
                  []
                }
                turn={
                  filters.personalTurn
                }
                isLoading={isLoading}
                error={error}
              />
            </LazyChartMount>

            <LazyChartMount>
              <PersonalTotalPorTurnoChart
                totals={
                  data?.personalTotales ?? {
                    tm: 0,
                    tv: 0,
                  }
                }
                turn={
                  filters.personalTurn
                }
                isLoading={isLoading}
                error={error}
              />
            </LazyChartMount>

            <LazyChartMount>
              <PersonalTotalPorCuatrimestreChart
                data={
                  data?.personalPorCuatrimestre ??
                  []
                }
                isLoading={isLoading}
                error={error}
              />
            </LazyChartMount>
          </div>
        )}
      </ComponentSection>

      <ComponentSection
        title="Capital estadías"
        description="Participación por carrera, nivel académico y cuatrimestre."
      >
        <ReportSectionFilters
          section="internships"
          filters={filters}
          options={filterOptions}
          isLoading={
            loadingFilterOptions
          }
          onChange={updateFilters}
        />

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          <StatCard
            label="Registros"
            value={
              data?.estadiasTotales
                .registros ?? 0
            }
            isLoading={isLoading}
            decimals={0}
          />

          <StatCard
            label="Cuatrimestres"
            value={
              data?.estadiasTotales
                .cuatrimestres ?? 0
            }
            isLoading={isLoading}
            accent="sky"
            decimals={0}
          />

          <StatCard
            label="Carreras participantes"
            value={
              data?.estadiasTotales
                .carreras ?? 0
            }
            isLoading={isLoading}
            decimals={0}
          />

          <StatCard
            label="Participación total"
            value={
              data?.estadiasTotales
                .participantes ?? 0
            }
            isLoading={isLoading}
            accent="sky"
            decimals={0}
          />
        </div>

        {!isLoading &&
        !error &&
        !hasInternshipResults ? (
          <div className="mt-6">
            <NoResultsNotice
              title="Sin datos de Capital estadías"
              description="No hay participaciones que coincidan con el periodo, carrera y nivel seleccionados."
            />
          </div>
        ) : (
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <LazyChartMount>
              <EstadiasPorCarreraChart
                data={
                  data?.estadiasPorCarrera ??
                  []
                }
                isLoading={isLoading}
                error={error}
              />
            </LazyChartMount>

            <LazyChartMount>
              <EstadiasPorNivelChart
                data={
                  data?.estadiasPorNivel ??
                  []
                }
                isLoading={isLoading}
                error={error}
              />
            </LazyChartMount>

            <div className="lg:col-span-2">
              <LazyChartMount>
                <EstadiasPorCuatrimestreChart
                  data={
                    data?.estadiasPorCuatrimestre ??
                    []
                  }
                  isLoading={isLoading}
                  error={error}
                />
              </LazyChartMount>
            </div>
          </div>
        )}
      </ComponentSection>

      <ComponentSection
        title="Resumen de materiales"
        description="Detalle tabular de los materiales incluidos en los filtros de Residuos."
      >
        <ResumenMaterialesTable
          materials={
            data?.materialTotals ?? []
          }
          total={
            data?.totalHistorico ?? 0
          }
          isLoading={isLoading}
        />
      </ComponentSection>
    </div>
  );
}

interface NoResultsNoticeProps {
  title: string;
  description: string;
}

function NoResultsNotice({
  title,
  description,
}: NoResultsNoticeProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 px-6 py-12 text-center dark:border-slate-700 dark:bg-slate-950/40">
      <div className="rounded-full bg-slate-200 p-3 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
        <FiInbox
          size={24}
          aria-hidden="true"
        />
      </div>

      <p className="mt-4 font-semibold text-slate-700 dark:text-slate-200">
        {title}
      </p>

      <p className="mt-1 max-w-md text-sm text-slate-500 dark:text-slate-400">
        {description}
      </p>
    </div>
  );
}

function countActiveFilters(
  filters: ReportFilters
): number {
  return (
    Number(
      filters.periodMode !== "all"
    ) +
    Number(
      Boolean(filters.material)
    ) +
    Number(
      filters.personalTurn !==
        "all"
    ) +
    Number(
      Boolean(
        filters.academicProgramId
      )
    ) +
    Number(
      Boolean(
        filters.academicLevel
      )
    )
  );
}